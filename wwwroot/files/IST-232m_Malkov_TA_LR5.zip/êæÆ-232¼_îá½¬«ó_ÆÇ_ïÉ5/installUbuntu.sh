#!/bin/bash

# Установка Dialog (если не установлено)
if ! command -v dialog &> /dev/null; then
  if command -v apt-get &> /dev/null; then
    sudo apt-get update
    sudo apt-get install -y dialog
    GUI = 1
  elif command -v dnf &> /dev/null; then
    sudo dnf install -y dialog
    GUI = 1
  elif command -v yum &> /dev/null; then
    sudo yum install -y dialog
    GUI = 1
  else
    echo "Не удалось найти менеджер пакетов для установки Dialog. Пожалуйста, установите Dialog вручную и запустите скрипт снова."
    GUI = 0
    exit 1
  fi
fi
# Запрос выбора директории
APP_DIR=$(dialog --title "Выберите директорию для установки" --dselect "$HOME" 0 0 3>&1 1>&2 2>&3)

# Проверка выбора директории
if [ -z "$APP_DIR" ]; then
  echo "Директория не выбрана. Установка отменена."
  exit 0
fi
sudo apt-get install unzip -y
components=$(dialog --checklist "Выберите компоненты для установки" 0 0 0 \
  "Apache" "" ON \
  "FTP" "" OFF \
  "ASP.NET" "" OFF \
  "Project" "" OFF 3>&1 1>&2 2>&3)
  
# Определение дистрибутива
. /etc/os-release

# Установка зависимостей в зависимости от дистрибутива
if [ "$ID" = "ubuntu" ]; then
    for component in $components; do
	case $component in "Apache")
		echo "Установка Apache..."
		sudo apt-get install apache2 -y
		# Конфигурация Apache
		echo "<VirtualHost *:80>
			ServerName localhost
			ProxyPreserveHost On
			ProxyPass / http://localhost:7891/
			ProxyPassReverse / http://localhost:7891/
			ErrorLog ${APACHE_LOG_DIR}/error.log
			CustomLog ${APACHE_LOG_DIR}/access.log combined
</VirtualHost>" | sudo tee /etc/apache2/sites-available/site.conf
		sudo a2dissite 000-default
		sudo a2ensite site.conf
	;;
	"FTP")
		echo "Установка FTP-сервера..."
		sudo apt-get install vsftpd -y
		# Конфигурация FTP
		sudo mkdir /home/ftpuser
		sudo mkdir /home/ftpuser/ftp
		sudo useradd ftpuser
		sudo passwd ftpuser
		sudo chown ftpuser:ftpuser /home/ftpuser/ftp
		echo "listen=NO
		listen_ipv6=YES
		local_root=/home/ftpuser/ftp
		anonymous_enable=NO
		local_enable=YES
		write_enable=YES
		local_umask=022
		dirmessage_enable=YES
		use_localtime=YES
		xferlog_enable=YES
		connect_from_port_20=YES
		chroot_local_user=YES
		secure_chroot_dir=/var/run/vsftpd/empty
		pam_service_name=vsftpd
		rsa_cert_file=/etc/ssl/certs/ssl-cert-snakeoil.pem
		rsa_private_key_file=/etc/ssl/private/ssl-cert-snakeoil.key
		ssl_enable=NO" | sudo tee /etc/vsftpd.conf
	;;
	"ASP.NET")
		echo "Установка ASP.NET Core MVC..."
		  echo "$(tput setaf 3)Installing .Net 6$(tput sgr0)"
		sudo apt-get remove 'dotnet*' -y
		sudo apt-get remove 'aspnetcore*' -y
		sudo apt-get remove 'netstandard*' -y
		sudo rm /etc/apt/sources.list.d/microsoft-prod.list
		sudo rm /etc/apt/sources.list.d/microsoft-prod.list.save
		sudo apt-get update
		sudo apt-get install dotnet6 -y
	;;
	"Project")
		# Скачивание и распаковка проекта
		wget https://github.com/lobstore/Lab5/archive/main.zip
		sudo unzip main.zip -d $APP_DIR
		rm -rf main.zip
		# Сборка и установка проекта
		dotnet restore $APP_DIR
		dotnet build $APP_DIR
		dotnet publish $APP_DIR/Lab5-main --output $APP_DIR/app/ -c Release
	;;
	esac
    done
fi
sudo a2enmod proxy
sudo a2enmod proxy_http
sudo systemctl reload apache2
sudo systemctl restart vsftpd

# Сообщение об успешной установке
dialog --title "Установка завершена" --msgbox "Все компоненты успешно установлены в директорию: $APP_DIR" 0 0
