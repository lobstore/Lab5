#!/bin/bash

str="Малков Тихон ИСТ232м"

# create individual text files in different encodings
for encoding in CP866 WINDOWS-1251 KOI8-R UTF-8
do
    iconv -f UTF-8 -t $encoding > $encoding.txt <<EOF
$(for i in {1..10000}; do echo "$str"; done)
EOF

    # transliterate the file content using Python and the transliterate module
    python3 -c "from transliterate import translit; import codecs; content=codecs.open('$encoding.txt', 'r', '$encoding').read(); print(translit(content, 'ru', reversed=True).upper())" > transliterated_$encoding.txt
done

# create a combined file
cat transliterated_*.txt > combined.txt

