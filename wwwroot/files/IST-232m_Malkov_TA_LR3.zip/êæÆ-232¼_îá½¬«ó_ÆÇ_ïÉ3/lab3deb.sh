 #!/bin/bash

str="Малков Тихон ИСТ-232м"

for i in {1..100}; do
    echo "$str" | iconv -f UTF-8 -t CP866 >> cp866.txt
    echo "$str" | iconv -f UTF-8 -t WINDOWS-1251 >> windows-1251.txt
    echo "$str" | iconv -f UTF-8 -t KOI8-R >> koi8.txt
    echo "$str" | iconv -f UTF-8 -t UTF-8 >> utf-8.txt
done

cat cp866.txt windows-1251.txt koi8.txt utf-8.txt > output.txt
# compress each file using different archiving utilities
FILES="cp866.txt windows-1251.txt koi8.txt utf-8.txt output.txt"
for f in $FILES 
do
    NAME="${f%.*}"
    arj a -r "$NAME.arj" "$f"
    gzip -c "$f" > "$NAME.gz"
    zip "$NAME.zip" "$f"
    tar -czvf "$NAME.tar.gz" "$f"
    bzip2 -c "$f" > "$NAME.bz2"
done
echo "Done."