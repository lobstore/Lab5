#!/bin/bash

str="Малков Тихон ИСТ-232м"

for i in {1..50000}; do
    echo "$str" | iconv -f UTF-8 -t CP866 >> cp866.txt
    echo "$str" | iconv -f UTF-8 -t WINDOWS-1251 >> windows-1251.txt
    echo "$str" | iconv -f UTF-8 -t KOI8-R >> koi8.txt
    echo "$str" | iconv -f UTF-8 -t UTF-8 >> utf-8.txt
done

cat cp866.txt windows-1251.txt koi8.txt utf-8.txt > output.txt
